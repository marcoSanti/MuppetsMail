package org.prog3.project.muppetsmail.SharedModel.Exceptions;

public class MailBoxNotFoundException extends Exception {
    public MailBoxNotFoundException(String message){
        super(message);
    }
}
