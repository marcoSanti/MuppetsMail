package org.prog3.project.muppetsmail.Server.Model;

public class Constants {
    public static final int MAILBOX_INBOX_FOLDER = 1;
    public static final int MAILBOX_SENT_FOLDER = 2;
    public static final int MAILBOX_DELETED_FOLDER = 3;
}
