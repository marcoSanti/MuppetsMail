package org.prog3.project.muppetsmail.SharedModel.Exceptions;

public class MailNotFoundException extends Exception{
    public MailNotFoundException(String message){
        super(message);
    }
}
