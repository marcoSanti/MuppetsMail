package org.prog3.project.muppetsmail.SharedModel.Exceptions;

public class MailBoxNameDuplicated extends Exception {
    public MailBoxNameDuplicated(String message){
        super(message);
    }
}
